import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function DeleteAccountButton() {
  const [userId, setUserId] = useState(null)

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) setUserId(user.id)
    }
    getUser()
  }, [])

  const handleDelete = async () => {
    if (!userId) return alert('Usuário não autenticado')

    const confirm = window.confirm('Tem certeza que deseja excluir sua conta?')
    if (!confirm) return

    const res = await fetch('/api/delete-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    })

    const data = await res.json()
    if (data.success) {
      alert('Conta excluída com sucesso!')
      await supabase.auth.signOut()
      window.location.href = '/'
    } else {
      alert('Erro ao excluir conta: ' + data.error)
    }
  }

  return (
    <button onClick={handleDelete} className="bg-red-600 text-white p-2 rounded">
      Excluir Conta
    </button>
  )
}
